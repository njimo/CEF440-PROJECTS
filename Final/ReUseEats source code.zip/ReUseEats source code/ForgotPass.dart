

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:progress_dialog_null_safe/progress_dialog_null_safe.dart';
import 'package:untitled1/Loginstyle/style.dart';
import 'package:untitled1/Interfaces/header_file.dart';
import 'package:untitled1/Interfaces/registration.dart';


Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(MaterialApp(
      theme:ThemeData(
          primarySwatch: Colors.green
      ),
      debugShowCheckedModeBanner: false,
      home: Forgotpass()
  ));
}

class Forgotpass extends StatefulWidget{
  const Forgotpass({super.key});


  @override
  _Forgotpass createState() => _Forgotpass();


}

class _Forgotpass extends State<Forgotpass> {
  final _formkey = GlobalKey<FormState>();
  double _headerheight = 250;
  bool toogle = true;

  final cont_pass = TextEditingController();


  @override
  Widget build(BuildContext context) {
    final ProgressDialog pr = ProgressDialog(context,type: ProgressDialogType.normal, isDismissible: true, showLogs: false);
    pr.style(
      message: "Checking email....",
      messageTextStyle: GoogleFonts.akayaKanadaka(fontSize: 20),
      progressTextStyle: TextStyle(color: Colors.green),
      elevation: 0,
      borderRadius: 15,
      insetAnimCurve: Curves.bounceInOut
    );
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Container(
          child: Stack(
            children: [
              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.only(top: 50),
                height:250,
                child: Image(
                  image: AssetImage("assets/pass.png"),
                )
              ),

              Container(
                padding: EdgeInsets.only(left: 30,right: 30),
                margin: EdgeInsets.only(top: 310),
                alignment: Alignment.center,
                child: Column(
                  children: [
                    Form(
                      key: _formkey,
                        child: Column(
                          children: [
                            Text(
                              "Reset Your Password ",
                              style: GoogleFonts.akayaKanadaka(
                                fontSize: 25,color: Colors.green
                              ),
                            ),
                            SizedBox(height: 60),
                            TextFormField(
                              keyboardType: TextInputType.visiblePassword,
                              controller: cont_pass,
                              decoration: loginstyle().logindecoration('Email Address', 'Enter Your Email',Icons.email_sharp),
    validator: (val) {
    if(val!.isEmpty){
    return ("Enter Your Email");
    }}
                            ),
                            SizedBox(height: 100),
                            Container(
                              decoration: loginstyle().boxDecoration(context),
                              child: ElevatedButton(
                                style: ButtonStyle(
                                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                      RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(30.0),
                                      ),
                                    ),
                                    minimumSize: MaterialStateProperty.all(Size(400,50)),
                                    backgroundColor: MaterialStateProperty.all(Colors.transparent),
                                    shadowColor: MaterialStateProperty.all(Colors.transparent)
                                ),
                                  onPressed: () async {
                                if(_formkey.currentState!.validate()) {
                                  await pr.show();
                                      FirebaseAuth.instance.sendPasswordResetEmail(
                                          email: cont_pass.text ).then((value) async{
                                            await pr.hide();
                                        final snackBar = SnackBar(content: Text("Check Your Email Account"),
                                            backgroundColor: Colors.lightGreen,

                                        );
                                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                            Navigator.of(context).pop();

                                      }).onError((error, stackTrace){
                                        final snackBar = SnackBar(content: Text("${error.toString()}"),
                                          backgroundColor: Colors.lightGreen
                                        );

                                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                      });


                                }

                                  },
                                child: Text(
                                  " Reset  ",
                                  style: GoogleFonts.akayaKanadaka(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 23,
                                  ),
                                ),

                              ),
                            )
                          ],
                        )
                    )

                  ],
                ),
              )

            ],
          ),
        ),
      ),
    );
  }
}



