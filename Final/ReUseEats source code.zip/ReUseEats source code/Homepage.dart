

import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:getwidget/components/avatar/gf_avatar.dart';
import 'package:getwidget/components/list_tile/gf_list_tile.dart';
import 'package:getwidget/getwidget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:outline_search_bar/outline_search_bar.dart';
import 'package:profile_photo/profile_photo.dart';
import 'package:progress_dialog_null_safe/progress_dialog_null_safe.dart';
import 'package:quickalert/quickalert.dart';
import 'package:untitled1/Interfaces/ForgotPass.dart';
import 'package:untitled1/Interfaces/Homescreen.dart';
import 'package:untitled1/Interfaces/Myaccount.dart';
import 'package:untitled1/Interfaces/food.dart';
import 'package:untitled1/Loginstyle/drawer.dart';
import 'package:firebase_core/firebase_core.dart';


Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Home(),

  ));
}

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);
  @override
  _Home createState() => _Home();

}
class _Home extends State<Home>{
 
  @override
  void initState() {
    getClient();
    cont_search.addListener(search);
    super.initState();
  }

  search(){
    print(cont_search.text);
    searchresults();

  }
  searchresults(){
    var showresults=[];
    if(cont_search.text != ""){
      for (var Client in _results){
        var name = Client['name'].toString().toLowerCase();
        var price = Client['price'].toString().toLowerCase();
        var Expdate= Client['Expdate'].toString().toLowerCase();
        var Cat = Client['Category'].toString().toLowerCase();
        if(name.contains(cont_search.text.toLowerCase()) || price.contains(cont_search.text.toLowerCase())
            || Expdate.contains(cont_search.text.toLowerCase()) || Cat.contains(cont_search.text.toLowerCase()))
          {
            showresults.add(Client);
          }
      }

    }else{
      showresults = List.from(_results);
    }
    setState(() {
      _searchresults = showresults;
    });
  }

  List _results= [];
  List _searchresults= [];
  final cont_search = TextEditingController();

  getClient()async{

    DateTime uploaddate = DateTime.now();
    String uploadformat = DateFormat('yyyy-MM-dd').format(uploaddate);
    FirebaseFirestore.instance.collection("Food_Post").where("Expdate",isEqualTo:
    uploadformat).get().then((QuerySnapshot snapshot){
      snapshot.docs.forEach((DocumentSnapshot doc) {
        FirebaseFirestore.instance.collection("Food_Post").doc(doc.id).delete();
      });
    });

    var data = await FirebaseFirestore.instance.collection("Food_Post").get();
    setState(() {
      _results = data.docs;
    });
    searchresults();
  }
  @override
  void dispose() {
    cont_search.removeListener(search);
    cont_search.dispose();
    super.dispose();
  }
  @override
  void didChangeDependencies() {
   getClient();
    super.didChangeDependencies();
  }


  @override
  Widget build(BuildContext context) {

   CollectionReference _reference = FirebaseFirestore.instance.collection("Food_Post");
   AsyncSnapshot<QuerySnapshot> snapshot;

   final ProgressDialog pr = ProgressDialog(context,type: ProgressDialogType.normal, isDismissible: true, showLogs: false);


    /*
   return WillPopScope(
     onWillPop:
         () async {
       final shouldPop = await showDialog<bool>(
         context: context,
         builder: (context) {
           return AlertDialog(
             title: const Text('Are Sure you want to quit?'),
             actionsAlignment: MainAxisAlignment.spaceBetween,
             actions: [
               TextButton(
                 onPressed: () {
                  _auth.signOut();
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Homepage()));
                 },
                 child: const Text('Yes'),
               ),
               TextButton(
                 onPressed: () {
                   Navigator.pop(context, false);
                 },
                 child: const Text('No'),
               ),
             ],
           );
         },
       );
       return shouldPop!;
     },*/
   return Scaffold(
     resizeToAvoidBottomInset: false,
       backgroundColor: Colors.white,
       drawer: const drawer(),
     appBar: AppBar(
       iconTheme: IconThemeData(
         color: Colors.green
       ),
       backgroundColor: Colors.white,
       elevation: 0,
       centerTitle: true,
       title: Text(
           'ReUseEats',
           style: GoogleFonts.akayaKanadaka(
             fontSize: 40,
             color: Colors.black
           ),
           ),
       actions: [
         Column(
           children: [
             SizedBox(height: 13,),

               InkWell(
                 onTap:(){
                   Navigator.push(context, MaterialPageRoute(builder: (context)=> myaccount()));
                 },
                 child: CircleAvatar(
                   backgroundColor: Colors.white,
                   radius: 14,
                   backgroundImage: NetworkImage(
                     "${FirebaseAuth.instance.currentUser?.photoURL}"
                   ),
                 ),
               )

           ],
         )
       ],
       ),

body:
      Column(
        children: [
          Container(
            margin: EdgeInsets.only(top: 20),
            alignment: Alignment.center,
            child: Text(
              "Available food items are shown here",
              style: GoogleFonts.akayaKanadaka(fontSize: 20,fontStyle: FontStyle.italic),
            ),
          ),
          SizedBox(height: 15),
          Container(
            height: 40,
            margin: EdgeInsets.only(left: 10),
            alignment: Alignment.topLeft,
            padding: EdgeInsets.only(right: 16),
            child: OutlineSearchBar(
              textEditingController: cont_search,

              searchButtonIconColor: Colors.green,
              textInputAction: TextInputAction.search,
              backgroundColor: Colors.lightBlue.shade50,
              borderRadius: BorderRadius.all(Radius.circular(15)),
              searchButtonPosition: SearchButtonPosition.leading,
              enableSuggestions: true,
              clearButtonIconColor: Colors.green,
              elevation: 2,
              hintText: "Search....",
              hintStyle: GoogleFonts.akayaKanadaka(fontSize: 18),
              textStyle: GoogleFonts.akayaKanadaka(fontSize: 15),
            ),
          ),
          const SizedBox(height: 20),
               Container(
                 height: MediaQuery.of(context).size.height -225,
                   child: RefreshIndicator(
                     onRefresh: (){
                       return getClient();
                     },
                     child: ListView.builder(
                       shrinkWrap: true,
                                          itemCount: _searchresults.length,
                                          itemBuilder: (BuildContext context,int index){

                         return GFListTile(
                                                  focusColor: Colors.green,
                                                  color: Colors.white,
                                                  hoverColor: Colors.green,
                                                  onTap: (){
                                                    Navigator.push(context,MaterialPageRoute(builder: (context) => foodpub(index: index,)));
                                                  },
                                                  title:
                                                      Text(_searchresults[index]['name'],style: GoogleFonts.akayaKanadaka(fontSize: 20,)),

                                                      description: Row(
                                                        children: [
                                                          Icon(
                                                            Icons.fastfood_rounded,size: 12,color: Colors.green,
                                                          ),
                                                          Text(_searchresults[index]['Category'],style: GoogleFonts.akayaKanadaka(fontSize: 12,fontStyle: FontStyle.italic)),
                                                        ],
                                                      ),
                                                    avatar: GFAvatar(backgroundImage: NetworkImage(_searchresults[index]['Imageurl']),radius: 35,),
                                                  subTitle: Text(_searchresults[index]['price'],style: GoogleFonts.akayaKanadaka(fontSize: 15,wordSpacing: 14,fontWeight: FontWeight.bold,color: Colors.green)),
                                                  enabled: true,
                                                  icon: Text(_searchresults[index]['Expdate'],style: GoogleFonts.akayaKanadaka(color: Colors.red,fontWeight: FontWeight.bold),),

                                                  );




                                          }),
                   ),

               ),

          ],
      ),



     floatingActionButton: FloatingActionButton(
       onPressed: () {
         Navigator.push(context,
         MaterialPageRoute(builder: (context) => food())
         );
       },
       backgroundColor: Colors.green,
       child: const Icon(
         Icons.add,
         size: 30,
       ),

     ),
     floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,

     );

  }

}


class foodpub extends StatefulWidget {
  const foodpub( {Key? key, required this.index}) : super(key: key);
  final int index;

  @override

  _foodpub createState() => _foodpub();

}

class _foodpub extends State<foodpub>{


  @override
  Widget build(BuildContext context) {
    final key = GlobalKey<ScaffoldState>();

    return Scaffold(
      key: key,
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          "Product & Seller Details", style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(
          color: Colors.green,
        ),
        shadowColor: Colors.white,
        elevation: 0,
      ),

         body:StreamBuilder(
          stream: FirebaseFirestore.instance.collection("Food_Post").snapshots(),
          builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
            if(snapshot.hasError){
              return Center(
                child: Text("Nothing to Show"),
              );
            }else{

                return ListView.builder(
                  itemCount: 1,
                    itemBuilder: (BuildContext context, index){
                      return Card(
                        margin: EdgeInsets.only(top: 20),
                        shadowColor: Colors.black,

                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                            color: Colors.green
                          ),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Column(
                          children: [
                            CircleAvatar(
                              backgroundImage: NetworkImage(
                                "${snapshot.data?.docs[widget.index]['Imageurl']}"
                              ),
                              radius: 120,
                            ),
                            SizedBox(height: 20,),

                            Text("Product Details",style: GoogleFonts.akayaKanadaka(decoration: TextDecoration.underline,fontSize: 15,fontWeight: FontWeight.bold,fontStyle: FontStyle.italic),),

                            SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,

                              children: [
                                Text("Item :",style: GoogleFonts.akayaKanadaka(fontSize: 20)),

                                Text("${snapshot.data?.docs[widget.index]['name']}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20,decoration: TextDecoration.underline),)
                              ],
                            ),
                            SizedBox(height: 5,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Price:",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                      Text("${snapshot.data?.docs[widget.index]['price']}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.green)),
                              ],
                            ),
                            SizedBox(height: 5,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Quantity:",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                      Text("${snapshot.data?.docs[widget.index]['quantity']}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20)),
                              ],
                            ),
                            SizedBox(height: 5),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Category:",style: GoogleFonts.akayaKanadaka(fontSize: 20),),

                                Text("${snapshot.data?.docs[widget.index]['Category']}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20)),

                              ],
                            ),
                            SizedBox(height: 5,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Expiring Date:",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                                Text("${snapshot.data?.docs[widget.index]['Expdate']}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.red)),

                              ],
                            ),
                            SizedBox(height: 30,),
                            CircleAvatar(
                              backgroundColor: Colors.white,
                              backgroundImage: NetworkImage(
                                  "${snapshot.data?.docs[widget.index]['Picture']}"
                              ),
                              radius: 100,
                            ),
                            SizedBox(height: 10,),
                            Text("Seller Details",style: GoogleFonts.akayaKanadaka(decoration: TextDecoration.underline,fontSize: 15,fontWeight: FontWeight.bold,fontStyle: FontStyle.italic),),
                            SizedBox(height: 20),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,

                              children: [
                                Text("Seller :",style: GoogleFonts.akayaKanadaka(fontSize: 20)),
                                GestureDetector(
                                    onLongPress: (){
                                      Clipboard.setData(ClipboardData(text: "${snapshot.data?.docs[widget.index]['Username']}")).then((_){
                                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(duration:Duration(seconds: 1),content: Text("Copied",style: GoogleFonts.akayaKanadaka(color: Colors.green),)));
                                      });

                                    },
                                    child: Text("${snapshot.data?.docs[widget.index]['Username']}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20,decoration: TextDecoration.underline)))
                              ],
                            ),
                            SizedBox(height: 5,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Number:",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                                GestureDetector(
                                    onLongPress: (){
                                      Clipboard.setData(ClipboardData(text: "${snapshot.data?.docs[widget.index]['Number']}")).then((_){
                                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(duration:Duration(seconds: 1),content: Text("Copied",style: GoogleFonts.akayaKanadaka(color: Colors.green),)));
                                      });

                                    },
                                    child: Text("${snapshot.data?.docs[widget.index]['Number']}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20)))
                              ],
                            ),
                            SizedBox(height: 5,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Location:",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                                GestureDetector(
                                  onLongPress: (){
                                    Clipboard.setData(ClipboardData(text: "${snapshot.data?.docs[widget.index]['Location']}")).then((_){
                                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(duration:Duration(seconds: 1),content: Text("Copied",style: GoogleFonts.akayaKanadaka(color: Colors.green),)));
                                    });

                                  },
                                    child: Text("${snapshot.data?.docs[widget.index]['Location']}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20))),
                              ],
                            ),
                            SizedBox(height: 5,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Email:",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                                GestureDetector(
                                    onLongPress: (){
                                      Clipboard.setData(ClipboardData(text: "${snapshot.data?.docs[widget.index]['Email']}")).then((_){
                                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(duration:Duration(seconds: 1),backgroundColor:Colors.white,content: Text("Copied",style: GoogleFonts.akayaKanadaka(color: Colors.green),)));
                                      });

                                    },
                                    child: Text("${snapshot.data?.docs[widget.index]['Email']}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20)))
                              ],
                            ),
                          ],
                        ),
                      );

                    }
                );

            }

          },

        ),
      
    );



  }
}

