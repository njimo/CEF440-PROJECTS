import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: market(),
  ));
}
class market extends StatefulWidget{
  const market({super.key});


  @override
  _marketState createState() => _marketState();

}

class _marketState extends State<market>{
  @override

  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
  }
