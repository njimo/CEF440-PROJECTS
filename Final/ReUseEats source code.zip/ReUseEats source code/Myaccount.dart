import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:untitled1/Interfaces/fooditem.dart';
import 'package:untitled1/Loginstyle/Profile.dart';
import 'package:untitled1/Loginstyle/style.dart';

class myaccount extends StatelessWidget{


  @override


  Widget build(BuildContext context) {
    String img ="";
    return Scaffold(
      backgroundColor:  Colors.white,
      appBar: AppBar(
        title: Text(
          "My Account", style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(
          color: Colors.green,
        ),
        shadowColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.only(left: 80),
          margin: EdgeInsets.only(top: 50),
          child: Column(
            children: [
            SizedBox(height: 40,),
              CircleAvatar(
                backgroundColor: Colors.white,
                radius: 120,
                backgroundImage: NetworkImage(
                  "${FirebaseAuth.instance.currentUser?.photoURL}"
                ),
              ),
              SizedBox(height: 10,),
              Column(
                children: [
                  Container(
                    decoration: loginstyle().boxDecoration(context),
                    child: ElevatedButton(
                      style: loginstyle().buttonStyle(),
                        onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>Profile()));

                        },
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(40, 10, 40, 10),
                          child: Text(
                            "My Profile",style: GoogleFonts.akayaKanadaka(fontSize: 20),
                          ),
                        )
                    ),
                  ),
SizedBox(height: 20),
                  Container(
                    decoration: loginstyle().boxDecoration(context),
                    child: ElevatedButton(
                        style: loginstyle().buttonStyle(),
                        onPressed: (){
Navigator.push(context, MaterialPageRoute(builder: (context) =>fooditem()));
                        },
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(40, 10, 40, 10),
                          child: Text(
                              "My Food Items",style: GoogleFonts.akayaKanadaka(fontSize: 20),
                          ),
                        )
                    ),
                  ),

                ],
              )

            ],
          ),
        ),
      ),
    );

  }
}