import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:progress_dialog_null_safe/progress_dialog_null_safe.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';
import 'package:untitled1/Interfaces/ForgotPass.dart';
import 'package:untitled1/Interfaces/Homepage.dart';
import 'package:untitled1/Loginstyle/style.dart';
import 'package:untitled1/Interfaces/header_file.dart';
import 'package:untitled1/Interfaces/registration.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(Myapp());

}


class Myapp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme:ThemeData(
          primarySwatch: Colors.green
      ),
      debugShowCheckedModeBanner: false,
      home: Homepage(),
    );

  }
  
}

class Homepage extends StatefulWidget{

  const Homepage({super.key});
  @override
 _HomepageState createState() => _HomepageState();


}

class _HomepageState extends State<Homepage>{

  Key _formkey= GlobalKey<FormState>();
  double _headerheight = 250;
  bool toogle = true;


  final cont_email = TextEditingController();
  final cont_pass= TextEditingController();

  @override

  Widget build(BuildContext context) {
   final ProgressDialog pr = ProgressDialog(context,type: ProgressDialogType.normal, isDismissible: true, showLogs: false);
   pr.style(
     message: "Checking....",
     messageTextStyle: GoogleFonts.akayaKanadaka(fontSize: 25),
     progressTextStyle: TextStyle(color: Colors.green),
     elevation: 0,
     borderRadius: 15,
     insetAnimCurve: Curves.bounceInOut
   );

    User? latestUser = FirebaseAuth.instance.currentUser;
   return Scaffold(
     backgroundColor: Colors.white,
     body: SingleChildScrollView(
       child: Column(
         children: [
           Container(
             height: _headerheight,
             child: HeaderWidget(_headerheight,true,Icons.login_rounded),
             ),
           SafeArea(
             child: Container(
               padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
               child: Column(
                 children: [
                   Text(
                     'Sign In Your Account ',
                 style: GoogleFonts.akayaKanadaka(
                     color: Colors.green,
                     decoration: TextDecoration.none,
                     fontSize: 25,
                     fontStyle: FontStyle.italic
                 )
                   ),
                   SizedBox(height: 25,),
                   Form(
                     key: _formkey,
                     child: Column(
                       children: [
                         TextFormField(
                           keyboardType: TextInputType.emailAddress,
                           controller: cont_email,
                           style: GoogleFonts.akayaKanadaka(
                           ),
                       validator: (val) {
                         if(val!.isEmpty){
                           return ("Please Enter Your Email Address");
                         }
                         bool email  = RegExp(r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(val);
                         if(!email){
                           return "Please enter a valid email address";
                         }
                         return null;
                       },
                         decoration: loginstyle().logindecoration("Email ","Please enter Your Email Address",Icons.email_sharp),
                   ),
               SizedBox(height: 16,),
                         TextFormField(
                           controller: cont_pass,
                           obscureText: toogle,
                           style: GoogleFonts.akayaKanadaka(
                           ),
                           decoration: InputDecoration(
                             labelText: "Password ",
                             hintText: "Please enter Your Password ",
                             fillColor: Colors.white, filled: true,
                             labelStyle: GoogleFonts.akayaKanadaka(
                                 fontWeight: FontWeight.bold, fontStyle: FontStyle.italic
                             ),
                             prefixIcon: Icon(
                               Icons.fingerprint_rounded, color: Colors.green,
                             ),
                             focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey)),
                             enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey.shade400)),
                             errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
                             focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
                             suffixIcon: InkWell(
                               onTap: () {
                                 setState(() {
                                   toogle = !toogle;
                                 });
                               },
                               child: Icon(
                                   toogle ?Icons.visibility_off :Icons.visibility
                               ),
                         ),
                           ),
                             validator:(val) {
                              if(val!.isEmpty){
                              return ("Enter your password ");
                              }
                              return null;}

                         ),
                         SizedBox(height: 23,),
                         Container(
                           child: Center(
                             child: Align(
                               alignment: Alignment.bottomRight,
                               child: TextButton(
                                 onPressed: () {
                                   Navigator.push(context, MaterialPageRoute(builder: (context) => Forgotpass()));
                                 },
                                 child: Text(
                                 "Forgot Password ?",
                                   style: GoogleFonts.akayaKanadaka(
                                     fontWeight: FontWeight.bold,
                                     fontSize: 17,
                                     color: Colors.black,
                                     decoration: TextDecoration.underline
                                   ),
                               ),
                               )
                             ),
                           )
                         ),
                         SizedBox(height: 30), // To fake a space
                         Container(
                           decoration: loginstyle().boxDecoration(context),
                           child: ElevatedButton(
                             style: loginstyle().buttonStyle(),
                             onPressed: () async {
                               await pr.show();
                               FirebaseAuth.instance.signInWithEmailAndPassword(
                                   email: cont_email.text,
                                   password: cont_pass.text).then((value) async {
                                     await pr.hide();
                                     Navigator.push(context, MaterialPageRoute(builder: (context) => Home()));
                              /*   QuickAlert.show(
                                     confirmBtnColor: Colors.green,
                                     context: context,
                                     type: QuickAlertType.success,
                                     confirmBtnText: "Continue",
                                     title: 'Success',
                                     text: "Welcome",
                                     onConfirmBtnTap: goto,
                                 );*/
                                 cont_pass.clear();
                                 cont_email.clear();
                               }).
                               onError((error, stackTrace) async {
                                 await pr.hide();
                                 QuickAlert.show(
                                     confirmBtnColor: Colors.red,
                                     context: context,
                                     confirmBtnText: "Try again",
                                     type: QuickAlertType.error,
                                     title: 'Oops',

                                     text: "${error.toString()}",
                                 );

                               });


                             },
                             child: Padding(
                               padding: EdgeInsets.fromLTRB(40, 10, 40, 10),
                               child: Text(
                                 'Log in',
                                 style: GoogleFonts.akayaKanadaka(
                                     fontWeight: FontWeight.bold,fontSize: 20
                                 ),
                               ),
                             ),

                           )
                         ),
                         SizedBox(height: 30),
                         Container(
                           child: Center(
                             child: Text.rich(
                               TextSpan(
                                 children: [
                                   TextSpan(
                                       style: GoogleFonts.akayaKanadaka(
                                       ),
                                       text: "Dont have an Account?"),
                                   TextSpan(
                                       text: " Register ",

                                     recognizer: TapGestureRecognizer()
                                       ..onTap= (){
                                         Navigator.push(context, MaterialPageRoute(builder: (context) => Registration()));
                                     },
                                     style: GoogleFonts.akayaKanadaka(color: Colors.green,decoration: TextDecoration.underline)
                                   )
                                 ]
                               )
                             )
                           )
                         )
                       ],
                     ),
                   )
                 ],
               ),
             ),
           )
         ],
       ),
     ),




   );
  }
  void goto(){
    Navigator.push(context, MaterialPageRoute(builder: (context) => Home()));
    cont_email.clear();
    cont_pass.clear();
  }
}
