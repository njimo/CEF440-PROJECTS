
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_email_sender/flutter_email_sender.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:progress_dialog_null_safe/progress_dialog_null_safe.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';

import 'Homepage.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(MaterialApp(
      theme:ThemeData(
          primarySwatch: Colors.green
      ),
      debugShowCheckedModeBanner: false,
      home: food()
  ));
}

class food extends StatefulWidget{
  const food({super.key});

  @override
  _foodState createState() => _foodState();

}

class _foodState extends State<food>{
  PlatformFile? pickedfile;
String id ="";
  User? latestUser = FirebaseAuth.instance.currentUser;

  CollectionReference _reference = FirebaseFirestore.instance.collection('Food_Post');

  String food ='';

  final _formkey = GlobalKey<FormState>();
  final cont_name = TextEditingController();
  final cont_price = TextEditingController();
  final cont_date = TextEditingController();
  final cont_qty = TextEditingController();
  String imageurl = '';
  String loc="",name="",num="",email = "";
  @override

  Widget build(BuildContext context) {
    final ProgressDialog pr1 = ProgressDialog(context,
        type: ProgressDialogType.normal, isDismissible: true,
        showLogs: false,
    );
    pr1.style(
        message: "Saving....",
        messageTextStyle: GoogleFonts.akayaKanadaka(fontSize: 25),
        progressTextStyle: TextStyle(color: Colors.black),
        borderRadius: 15,
        elevation: 0,
        insetAnimCurve: Curves.bounceInOut
    );


    Future uploadfood() async {
      if (pickedfile== null){
        QuickAlert.show(
          confirmBtnColor: Colors.red,
          context: context,
          type: QuickAlertType.error,
          confirmBtnText: "Try again",
          title: 'oops',
          text: "You need to give a Picture of the food",
        );

      }else {
        if (_formkey.currentState!.validate()) {
          await pr1.show();
          DateTime uploaddate = DateTime.now();
          String uploadformat = DateFormat('yyyy-MM-dd').format(uploaddate);

          Reference rootref = FirebaseStorage.instance.ref();
          Reference imgfol = rootref.child('Pictures');
          Reference foodim = imgfol.child('${pickedfile!.path}');

          Future<QuerySnapshot<Map<String,dynamic>>> map= FirebaseFirestore.instance.collection("Users").where("Username",
              isEqualTo: FirebaseAuth.instance.currentUser?.displayName.toString()).get();
          map.then((QuerySnapshot snapshot){
            snapshot.docs.forEach((DocumentSnapshot doc){
              loc =  doc["Location"];
              name = doc["Username"];
              num = doc["Number"];
              email = doc["Email"];
              String s = doc.id;

            });
          });

          try {
            await foodim.putFile(File(pickedfile!.path!));
            imageurl = await foodim.getDownloadURL();

            Map<String, String?> send = {
              'Category': food,
              'Expdate': cont_date.text,
              'Imageurl': imageurl,
              'name': cont_name.toString(),
              'Upload_date': uploadformat.toString(),
              'name': cont_name.text,
              'price': cont_price.text + "FCFA",
              'quantity': cont_qty.text,
              'Username':name,
              'Number':num,
              'Location':loc,
              'Email':email,
              'id':'',
              "Picture":FirebaseAuth.instance.currentUser?.photoURL
            };
            _reference.add(send).then((DocumentReference snapshot){
              id = snapshot.id;
              _reference.doc(id).update({'id':id});
            });

            Navigator.pop(context);

            

            await pr1.hide();
            cont_date.clear();
            cont_name.clear();
            cont_price.clear();
            cont_qty.clear();

          } on Exception catch (e) {
            await pr1.hide();
            QuickAlert.show(
              context: context,
              type: QuickAlertType.error,
              title: 'Oops...',
              text: '${e.toString()}',
            );
          }

        }
      }
    }


    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
            decoration: BoxDecoration(
              image: const DecorationImage(
                image: AssetImage("assets/3.jpg"),
                fit: BoxFit.cover
              ),
             borderRadius: BorderRadius.circular(25),
        ),
              margin: EdgeInsets.only(top: 25),
              width: MediaQuery.of(context).size.width,
              height: 140,

            ),
            SizedBox(height: 20),
            Text("Please Fill the Food Item Information ",
              style: GoogleFonts.akayaKanadaka(fontSize: 20,fontWeight: FontWeight.bold)),
           SizedBox(height: 30,),
            Container(
              padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
              child: Column(
                children: [
                  SingleChildScrollView(),
                  Form(
                    key: _formkey,
                    child: Column(
                      children: [
                        TextFormField(
                        controller: cont_name,
    validator: (val) {
    if(val!.isEmpty){
    return ("Provide food name");
    }},
                        decoration: InputDecoration(
                          prefixIcon: const Icon(
                            Icons.file_copy,color: Colors.green,
                          ),
                          labelText: "Food Name ",
                          hintText: "Enter the name of your food item",
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey)),
                          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey.shade400)),
                          errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
                          focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
labelStyle: GoogleFonts.akayaKanadaka(),
                          hintStyle: GoogleFonts.akayaKanadaka(),
                        ),
                      ),
                  SizedBox(height: 20),
                     TextFormField(
                       keyboardType: TextInputType.number,
                      controller: cont_price,
    validator: (val) {
    if(val!.isEmpty){
    return ("provide price");
    }},
                      decoration: InputDecoration(
                        prefixIcon: const Icon(
                          Icons.price_change,
                          color: Colors.green,
                        ),
                        suffixText: "FCFA",
                        suffixStyle: GoogleFonts.akayaKanadaka(color: Colors.green),
                        labelText: "Price ",
                        hintText: "Price of your food item in FCFA",
                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey)),
                        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey.shade400)),
                        errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
                        focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
                        labelStyle: GoogleFonts.akayaKanadaka(),
                        hintStyle: GoogleFonts.akayaKanadaka(),
                      ),
                    ),
                    SizedBox(height: 20,),
                        Container(
                          alignment: Alignment.topLeft,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                children: [
                                  Text("Quantity ",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold),),
                                  SizedBox(height: 10,),
                                  Container(
                                    width: 130,
                                    height: 50,
                                    alignment: Alignment.topLeft,
                                    child: TextFormField(
                                      keyboardType: TextInputType.number,
                                      validator: (val) {
                                        if(val!.isEmpty){
                                          return ("provide quantity");
                                        }},
                                      controller: cont_qty,
                                     decoration: InputDecoration(
                                       labelText: "Quantity ",
                                       hintText: "food quantity",
                                       focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey)),
                                       enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey.shade400)),
                                       errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
                                       focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
                                       labelStyle: GoogleFonts.akayaKanadaka(),
                                       hintStyle: GoogleFonts.akayaKanadaka(),
                                     ),
                                    ),
                                  )
                                ],
                              ),
                              Column(
                                children: [
                                  Text("Exp. Date ",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold),),
                                  SizedBox(height: 10,),
                                  Container(
                                    width: 150,
                                    height: 50,
                                    child: TextFormField(
                                      readOnly: true,
                                      onTap:  () async {
                                        DateTime? pickdate = await showDatePicker(
                                            context: context,
                                            initialDate: DateTime.now(), // can't choose a date before today
                                            firstDate: DateTime(DateTime.now().year),
                                            lastDate: DateTime(2500)
                                        );
                                        if (pickdate != null){
                                          String formatdate = DateFormat('yyyy-MM-dd').format(pickdate);
                                          setState(() {
                                            cont_date.text = formatdate;
                                          });
                                        }
                                      },
                                      validator: (val) {
                                        if(val!.isEmpty){
                                          return ("provide a date");
                                        }},
                                      keyboardType: TextInputType.datetime,
                                      controller: cont_date,
                                      decoration: InputDecoration(
                                        labelText: "Expiring Date ",
                                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey)),
                                        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey.shade400)),
                                        errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
                                        focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
                                        labelStyle: GoogleFonts.akayaKanadaka(),
                                        hintStyle: GoogleFonts.akayaKanadaka(),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ],
                          ),
                        ),
                    SizedBox(height: 20,),
                    Container(
                        alignment: Alignment.topLeft,
                        child: Text("Select the Food Category",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold),)),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Radio(
                          activeColor: Colors.green,
                            value: "cooked",
                            groupValue: food,
                            onChanged: (value){
                            setState(() {
                              food= value as String;
                            });
                            }
                        ),
                        Text("Cooked",style: GoogleFonts.akayaKanadaka(),),
                        SizedBox(width: 20,),
                        Radio(
                            activeColor: Colors.green,
                            value: "raw",
                            groupValue: food,
                            onChanged: (value){
                              setState(() {
                                food= value as String;
                              });
                            }
                        ),
                        Text("Raw",style: GoogleFonts.akayaKanadaka(),),
                        SizedBox(width: 20,),
                        Radio(
                            activeColor: Colors.green,
                            value: "Fruits&Vegetables",
                            groupValue: food,
                            onChanged: (value){
                              setState(() {
                                food= value as String;
                              });
                            }
                        ),
                        Text("F & V",style: GoogleFonts.akayaKanadaka(),),

                      ],
                    ),
                  SizedBox(height: 20,),
                  Container(
                    alignment: Alignment.topLeft,
                    child: Text(
                      "Choose a picture for the Food Item",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold),
                    ),
                  ),
                  SizedBox(height: 10,),
                  if (pickedfile!=null)
                      Container(
                        height: 200,
                          child: Image.file(
                            File(pickedfile!.path!),
                              fit: BoxFit.cover,
                            frameBuilder:  (BuildContext context, Widget child, int? frame, bool? wasSynchronouslyLoaded) {
                            return child;
                            },
                          ),
                      ),
                  SizedBox(height: 10,),
                  ElevatedButton(onPressed: selectpic,
                      child: Text(
                        "Select Picture ",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold),
                      )),
                  SizedBox(height: 100,),

                  ElevatedButton.icon(onPressed: uploadfood ,
                      icon: Icon(Icons.upload),
                      label: Text(' Upload ',style: GoogleFonts.akayaKanadaka(fontSize: 20),))
                ],
              ),
    ),
                  ],
            )
            ),
        ],
      ),

    ),
    );

  }

  Future selectpic() async{
    final result = await FilePicker.platform.pickFiles();
    if (result ==null) return;
    setState(() {
    pickedfile = result.files.first;
    });
  }
  Future sendemail(String recipient)async{
    bool html = false;
    final Email email = Email(
      body: "Mail ",
      subject: "ReUseEats",
      recipients: [recipient],
      isHTML: html, 

    );
    throw 1;
  }


  }
