
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled1/Interfaces/Homescreen.dart';


Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      primarySwatch: Colors.green
    ),
    home: Splash(),

  ));

}

class Splash extends StatelessWidget {
  const Splash({super.key});


  @override
  Widget build(BuildContext context) {

    return Scaffold(
        body: Container(

            child: Stack(
              children: [
                Positioned.fill(
                  child: Opacity(
                    opacity: 0.9,
                    child: Image.asset("assets/f3.jpg",
                      height: 25,
                      fit: BoxFit.cover,),
                  ),
                ),
                Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          'ReUseEats',
                          style: TextStyle(
                              color: Colors.green,
                              fontFamily: "Georgia",
                              decoration: TextDecoration.none,
                              fontSize: 30,
                              fontStyle: FontStyle.italic
                          ),
                        ),
                        SizedBox(height: 25,),
                        const Text(
                          "No Food Waste !",
                          style: TextStyle(
                              color: CupertinoColors.inactiveGray,
                              fontFamily: "Georgia",
                              decoration: TextDecoration.none,
                              fontSize: 15,
                              fontStyle: FontStyle.italic
                          ),
                        ),
                        SizedBox(height: 390),
                        TextButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
                            padding:MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.all(25)),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) => const Homepage())
                            );
                          },
                          child: Text(
                            'GetStarted!',
                            style: TextStyle(
                                color: Colors.black,
                                fontFamily: "Georgia",
                                fontWeight: FontWeight.bold
                            ),
                          ),
                        )
                      ],
                    )

                )
              ],
            )
        ),
    );
  }

}

