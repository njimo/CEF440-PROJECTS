import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:untitled1/Interfaces/Homescreen.dart';
import 'package:untitled1/Interfaces/Myaccount.dart';
import 'package:untitled1/Interfaces/fooditem.dart';
import 'package:untitled1/Loginstyle/Profile.dart';

import '../Interfaces/Splash.dart';

class drawer extends StatelessWidget{
  const drawer({Key? key}): super(key: key);

  Future main() async {
    WidgetsFlutterBinding.ensureInitialized();
    await Firebase.initializeApp();

    runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      home: drawer(),
    ));
  }


  @override
  Widget build(BuildContext context) {

    void profile(){
      Navigator.push(context, MaterialPageRoute(builder: (context) => myaccount()));
    }

    User? latestUser = FirebaseAuth.instance.currentUser;
    return Drawer(
        child: ListView(
          dragStartBehavior: DragStartBehavior.start,
          children: [
            UserAccountsDrawerHeader(
              accountName: Text("${latestUser?.displayName}",
            style: GoogleFonts.akayaKanadaka(color: Colors.white,fontSize: 21),),
              accountEmail: Text("${latestUser?.email}",style: GoogleFonts.akayaKanadaka(color: Colors.white,fontSize: 21)),
              currentAccountPicture:
                CircleAvatar(
                  radius: 15,
                  backgroundColor: Colors.white,
                  backgroundImage: NetworkImage("${FirebaseAuth.instance.currentUser?.photoURL}"),
                ),
              decoration: BoxDecoration(
                color: Colors.transparent,
                  image: DecorationImage(
                      image: NetworkImage(
"https://www.travelandleisure.com/thmb/NoW4DIuyqO4f5fLCCEFJ2rtxOwE=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/corcovado-national-park-costa-rica-GREENEST1221-a8a189f002904ac7b74d647b63b9ee10.jpg"                      ),
                    fit: BoxFit.cover

                  ),
              ),
            ),

            ListTile(
              leading: Icon(Icons.home, color: Colors.green,),
              title: Text("Home ", style: GoogleFonts.akayaKanadaka(
                  fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold
              )),
              onTap: null,
            ),
            Divider(color: Colors.green,height: 1,),
            ListTile(
              leading: Icon(Icons.account_circle_sharp, color: Colors.green,),
              title: Text("My Account ",style: GoogleFonts.akayaKanadaka(
              fontSize: 20, color: Colors.black,fontWeight: FontWeight.bold
              )),
              onTap:profile,
            ),
            Divider(color: Colors.green,height: 1,),
            ListTile(
              onTap: (){Navigator.push(context, MaterialPageRoute(builder: (context) => fooditem()));
              },
              leading: Icon(Icons.fastfood_rounded, color: Colors.green,),
              title: Text("My Food Items ",style:GoogleFonts.akayaKanadaka(
                  fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold
              )
              ),
            ),
            Divider(color: Colors.green,height: 1),
            ListTile(
              selectedColor: Colors.grey,
              leading: Icon(Icons.exit_to_app, color: Colors.green),
              title: Text("LogOut ",style: GoogleFonts.akayaKanadaka(
                  fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold
              )),
              onTap:(){
                FirebaseAuth.instance.signOut();
                Navigator.push(context, MaterialPageRoute(builder: (context)=> Splash()));

              },
            )


          ],
        ),
      );


  }


  Stream<List<Client>> read() => FirebaseFirestore.instance.
  collection("Account_Creation").snapshots().map((snapshot) =>
      snapshot.docs.map((doc) => Client.fromJson(doc.data())).toList());


}

class  Client {
  String id;
  final String uname;
  final String pass;
  final String email;
  final int num;


  Client({
    required this.id,
    required this.uname,
    required this.pass,
    required this.email,
    required this.num,
  });

  Map<String, dynamic> toJson() =>
      {
        'Email': email,
        'Id': id,
        'Number': num,
        'Password': pass,
        'Username': uname
      };


  static Client fromJson(Map<String, dynamic> json) =>
      Client(
   email: json['Email'],
     num: json['Number'],
     uname: json['Username'],
     pass: json['Password'],
        id: json['Id']
      );


}




