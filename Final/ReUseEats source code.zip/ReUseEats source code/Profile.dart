import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:profile_photo/profile_photo.dart';
import 'package:progress_dialog_null_safe/progress_dialog_null_safe.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';


Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(MaterialApp(
    theme: ThemeData(
      primaryColor: Colors.white,
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(
          color: Colors.white
        )
      )
    ),
    debugShowCheckedModeBanner: false,
    home: Profile(),

  ));
}

class Profile extends StatefulWidget {
  const Profile({Key? key}) : super(key: key);
  @override
  _Profile createState() => _Profile();

}
class _Profile extends State<Profile>{
  final _formkey = GlobalKey<FormState>();
  final cont_update = TextEditingController();

  Future modifyname(String value,String val){
    return showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            title: Text("Update $value",style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold),),
            content: TextFormField(
              controller: cont_update,
              decoration: InputDecoration(
                  hintText: val,
                  hintStyle: GoogleFonts.akayaKanadaka()
              ),
            ),
            actions: [
              MaterialButton(
                color: Colors.green,
                onPressed: ()async {
                    var up3 = FirebaseFirestore.instance.collection(
                        "Food_Post");
                    var up2 = FirebaseFirestore.instance.collection("Food_Post")
                        .where("Username",
                        isEqualTo: FirebaseAuth.instance.currentUser
                            ?.displayName.toString())
                        .get();
                    up2.then((QuerySnapshot snapshot) {
                      snapshot.docs.forEach((DocumentSnapshot document) async{
                     await   up3.doc(document.id).update({
                          value: cont_update.text
                        }).onError((error, stackTrace) =>
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                duration: Duration(seconds: 4),
                                content: Text("$error", style: GoogleFonts
                                    .akayaKanadaka(color: Colors.green),))),
                        );
                      });
                    });
                    var up1 = FirebaseFirestore.instance.collection("Users");
                    var up = FirebaseFirestore.instance.collection("Users")
                        .where("Username",
                        isEqualTo: FirebaseAuth.instance.currentUser
                            ?.displayName.toString())
                        .get();
                    up.then((QuerySnapshot snapshot) {
                      snapshot.docs.forEach((DocumentSnapshot document) async{
                       await up1.doc(document.id).update({
                          value: cont_update.text
                        }).onError((error, stackTrace) =>
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                duration: Duration(seconds: 4),
                                content: Text("$error", style: GoogleFonts
                                    .akayaKanadaka(color: Colors.green),))),
                        );
                      });
                    });

                    FirebaseAuth.instance.currentUser?.reload();
                    FirebaseAuth.instance.currentUser?.updateDisplayName(
                        cont_update.text).onError((error, stackTrace) =>
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            duration: Duration(seconds: 4),
                            content: Text("$error", style: GoogleFonts
                                .akayaKanadaka(color: Colors.green),))),
                    );

                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        duration: Duration(seconds: 1),
                        content: Text("Updated",
                          style: GoogleFonts.akayaKanadaka(
                              color: Colors.green),)));
                    cont_update.clear();
                    Navigator.pop(context);

                }
              ,child: Text(
                  "Update",style: GoogleFonts.akayaKanadaka(fontSize: 20),
                ),)
            ],
          );
        });
  }
  Future <void>modifyloc(String value,String val) async{
    return showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            title: Text("Update $value",style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold),),
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState)
          {
            return Form(
              key: _formkey,
                child: TextFormField(
                  validator: (val) {
                    if(val!.isEmpty){
                      return ("Enter a value ");
                    }
                  },
                  controller: cont_update,
                  decoration: InputDecoration(
                      hintText: val,
                      hintStyle: GoogleFonts.akayaKanadaka()
                  ),
                )
            );
          },
            ),
            actions: [
              MaterialButton(
                color: Colors.green,
                onPressed: () async{
                  if (_formkey.currentState!.validate()) {

                    var up3 = FirebaseFirestore.instance.collection(
                        "Food_Post");
                    var up2 = FirebaseFirestore.instance.collection("Food_Post")
                        .where("Username",
                        isEqualTo: FirebaseAuth.instance.currentUser
                            ?.displayName.toString())
                        .get();
                     await   up2.then((QuerySnapshot snapshot) {
                      snapshot.docs.forEach((DocumentSnapshot document) async {
                       await up3.doc(document.id).update({
                          value: cont_update.text
                        }).onError((error, stackTrace) =>
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                duration: Duration(seconds: 4),
                                content: Text("$error", style: GoogleFonts
                                    .akayaKanadaka(color: Colors.green),))),
                        );
                      });
                    });
                    print(cont_update.text);
                    var up1 = FirebaseFirestore.instance.collection("Users");
                    var up = FirebaseFirestore.instance.collection("Users")
                        .where("Username",
                        isEqualTo: FirebaseAuth.instance.currentUser
                            ?.displayName.toString())
                        .get();
                   await    up.then((QuerySnapshot snapshot) {
                      snapshot.docs.forEach((DocumentSnapshot document) async {
                       await up1.doc(document.id).update({
                          value: cont_update.text
                        }).onError((error, stackTrace) =>
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                duration: Duration(seconds: 4),
                                content: Text("$error", style: GoogleFonts
                                    .akayaKanadaka(color: Colors.green),))),
                        );
                      });
                    });
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        duration: Duration(seconds: 1),
                        content: Text("Updated",
                          style: GoogleFonts.akayaKanadaka(
                              color: Colors.green),)));
                    cont_update.clear();
                    Navigator.pop(context);
                  }
                }
                ,child: Text(
                "Update",style: GoogleFonts.akayaKanadaka(fontSize: 20),
              ),)
            ],
          );

        });
          }
  Future <void>modifynum(String value,String val) async{
    return showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            title: Text("Update $value",style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold),),
            content: TextFormField(
              controller: cont_update,
              decoration: InputDecoration(
                  hintText: val,
                  hintStyle: GoogleFonts.akayaKanadaka()
              ),
            ),
            actions: [
              MaterialButton(
                color: Colors.green,
                onPressed: () async{
                  var up3 = FirebaseFirestore.instance.collection(
                      "Food_Post");
                  var up2 = FirebaseFirestore.instance.collection("Food_Post")
                      .where("Username",
                      isEqualTo: FirebaseAuth.instance.currentUser
                          ?.displayName.toString())
                      .get();
                await  up2.then((QuerySnapshot snapshot) {
                    snapshot.docs.forEach((DocumentSnapshot document) async{
                    await  up3.doc(document.id).update({
                        value: cont_update.text
                      }).onError((error, stackTrace) =>
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              duration: Duration(seconds: 4),
                              content: Text("$error", style: GoogleFonts
                                  .akayaKanadaka(color: Colors.green),))),
                      );
                    });
                  });
                  var up1 = FirebaseFirestore.instance.collection("Users");
                  var up = FirebaseFirestore.instance.collection("Users")
                      .where("Username",
                      isEqualTo: FirebaseAuth.instance.currentUser
                          ?.displayName.toString())
                      .get();
                 await up.then((QuerySnapshot snapshot) {
                    snapshot.docs.forEach((DocumentSnapshot document) async{
                     await up1.doc(document.id).update({
                        value: cont_update.text
                      }).onError((error, stackTrace) =>
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              duration: Duration(seconds: 4),
                              content: Text("$error", style: GoogleFonts
                                  .akayaKanadaka(color: Colors.green),))),
                      );
                    });
                  });


                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      duration: Duration(seconds: 1),
                      content: Text("Updated",
                        style: GoogleFonts.akayaKanadaka(
                            color: Colors.green),)));
                  cont_update.clear();
                  Navigator.pop(context);

                }
                ,child: Text(
                "Update",style: GoogleFonts.akayaKanadaka(fontSize: 20),
              ),)
            ],
          );
        });
  }
  Future <void>modifyemail(String value,String val)async{
    return showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            title: Text("Update $value",style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold),),
            content: TextFormField(
              controller: cont_update,
              decoration: InputDecoration(
                  hintText: val,
                  hintStyle: GoogleFonts.akayaKanadaka()
              ),
            ),
            actions: [
              MaterialButton(
                color: Colors.green,
                onPressed: () {
                  var up3 = FirebaseFirestore.instance.collection(
                      "Food_Post");
                  var up2 = FirebaseFirestore.instance.collection("Food_Post")
                      .where("Username",
                      isEqualTo: FirebaseAuth.instance.currentUser
                          ?.displayName.toString())
                      .get();
                  up2.then((QuerySnapshot snapshot) {
                    snapshot.docs.forEach((DocumentSnapshot document)async {
                 await   up3.doc(document.id).update({
                        value: cont_update.text
                      }).onError((error, stackTrace) =>
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              duration: Duration(seconds: 4),
                              content: Text("$error", style: GoogleFonts
                                  .akayaKanadaka(color: Colors.green),))),
                      );
                    });
                  });
                  var up1 = FirebaseFirestore.instance.collection("Users");
                  var up = FirebaseFirestore.instance.collection("Users")
                      .where("Username",
                      isEqualTo: FirebaseAuth.instance.currentUser
                          ?.displayName.toString())
                      .get();
                  up.then((QuerySnapshot snapshot) {
                    snapshot.docs.forEach((DocumentSnapshot document) async{
                   await   up1.doc(document.id).update({
                        value: cont_update.text
                      }).onError((error, stackTrace) =>
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              duration: Duration(seconds: 4),
                              content: Text("$error", style: GoogleFonts
                                  .akayaKanadaka(color: Colors.green),))),
                      );
                    });
                  });

                  FirebaseAuth.instance.currentUser?.reload();
                  FirebaseAuth.instance.currentUser?.updateEmail(
                      cont_update.text).onError((error, stackTrace) =>
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          duration: Duration(seconds: 4),
                          content: Text("$error", style: GoogleFonts
                              .akayaKanadaka(color: Colors.green),))),
                  );

                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      duration: Duration(seconds: 1),
                      content: Text("Updated",
                        style: GoogleFonts.akayaKanadaka(
                            color: Colors.green),)));
                  cont_update.clear();
                  Navigator.pop(context);

                }
                ,child: Text(
                "Update",style: GoogleFonts.akayaKanadaka(fontSize: 20),
              ),)
            ],
          );
        });
  }
  Future <void>modifypass(String value,String val)async{
    return showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            title: Text("Update $value",style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold),),
            content: TextFormField(
              controller: cont_update,
              decoration: InputDecoration(
                  hintText: val,
                  hintStyle: GoogleFonts.akayaKanadaka()
              ),
            ),
            actions: [
              MaterialButton(
                color: Colors.green,
                onPressed: () async{
                  var up1 = FirebaseFirestore.instance.collection("Users");
                  var up = FirebaseFirestore.instance.collection("Users")
                      .where("Username",
                      isEqualTo: FirebaseAuth.instance.currentUser
                          ?.displayName.toString())
                      .get();
                  up.then((QuerySnapshot snapshot) {
                    snapshot.docs.forEach((DocumentSnapshot document) async {
                      await up1.doc(document.id).update({
                        value: cont_update.text
                      }).onError((error, stackTrace) =>
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              duration: Duration(seconds: 4),
                              content: Text("$error", style: GoogleFonts
                                  .akayaKanadaka(color: Colors.green),))),
                      );
                    });
                  });

                  FirebaseAuth.instance.currentUser?.reload();
                  FirebaseAuth.instance.currentUser?.updatePassword(
                      cont_update.text).onError((error, stackTrace) =>
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          duration: Duration(seconds: 4),
                          content: Text("$error", style: GoogleFonts
                              .akayaKanadaka(color: Colors.green),))),
                  );

                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      duration: Duration(seconds: 1),
                      content: Text("Updated",
                        style: GoogleFonts.akayaKanadaka(
                            color: Colors.green),)));
                  cont_update.clear();
                  Navigator.pop(context);

                }
                ,child: Text(
                "Update",style: GoogleFonts.akayaKanadaka(fontSize: 20),
              ),)
            ],
          );
        });
  }

  Future changepro() async{
    return showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            title: Text("Update Profile Pic",style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold),),
            content: Container(
              child: Column(
                children: [
                  if (pickedfile!=null)
                    Container(
                      height: 200,
                      child: Image.file(
                        File(pickedfile!.path!),
                        fit: BoxFit.cover,
                        frameBuilder:  (BuildContext context, Widget child, int? frame, bool? wasSynchronouslyLoaded) {
                          return child;
                        },
                      ),
                    ),
                  SizedBox(height: 10,),
                  ElevatedButton(onPressed:()async{
                    final result = await FilePicker.platform.pickFiles();
                    if (result ==null) return;
                    setState(() {
                      pickedfile = result.files.first;
                    });
                  },
                      child: Text(
                        "Select Picture ",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold),
                      )),

                ],
              ),
            ),
            actions: [
              MaterialButton(
                color: Colors.green,
                onPressed: () async {
                  Reference rootref = FirebaseStorage.instance.ref();
                  Reference imgfol = rootref.child('Profiles');
                  Reference foodim = imgfol.child('${pickedfile!.path}');

                  await foodim.putFile(File(pickedfile!.path!));
                 String  imageurl = await foodim.getDownloadURL();


                  var up3 = FirebaseFirestore.instance.collection(
                      "Food_Post");
                  var up2 = FirebaseFirestore.instance.collection("Food_Post")
                      .where("Username",
                      isEqualTo: FirebaseAuth.instance.currentUser
                          ?.displayName.toString())
                      .get();
                  up2.then((QuerySnapshot snapshot) {
                    snapshot.docs.forEach((DocumentSnapshot document)async {
                  await    up3.doc(document.id).update({
                        "Picture": imageurl
                      });
                    });
                  });
                  FirebaseAuth.instance.currentUser?.reload();
                  FirebaseAuth.instance.currentUser?.updatePhotoURL(imageurl);
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      duration: Duration(seconds: 1),
                      content: Text("Updated",
                        style: GoogleFonts.akayaKanadaka(
                            color: Colors.green),)));
                  Navigator.pop(context);
                  getClient();
                }
                ,child: Text(
                "Update",style: GoogleFonts.akayaKanadaka(fontSize: 20),
              ),)
            ],
          );
        });

  }

  @override
  void initState() {
    getClient();
    super.initState();
  }
  List results = [];
  getClient()async{
    var up = await FirebaseFirestore.instance.collection("Users").where("Username",
        isEqualTo: FirebaseAuth.instance.currentUser?.displayName.toString()).get();
    setState(() {
      results = up.docs;
    });
  }

  bool toogle = true;
  PlatformFile? pickedfile;

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          "Update Profile", style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(
          color: Colors.green,
        ),
        shadowColor: Colors.white,
        elevation: 0,
      ),
      body: RefreshIndicator(
        onRefresh: (){
          return getClient();
        },
        child: ListView.builder(
          itemCount: 1,
            itemBuilder: (context,index){
              return Column(
                children: [
                  SizedBox(height:20),
                  ListTile(
                    onTap:()async{
                      modifyname("Username","${FirebaseAuth.instance.currentUser?.displayName}");
                    },
                    focusColor: Colors.green,
                    hoverColor: Colors.green,
                    title: Text("Username",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing: Text("${FirebaseAuth.instance.currentUser?.displayName}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20),),
                  ),
                  ListTile(
                    onTap:()async{
                      modifyemail("Email","${FirebaseAuth.instance.currentUser?.email}");
                    },
                    focusColor: Colors.green,

                    hoverColor: Colors.green,
                    title: Text("Email",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing: Text("${FirebaseAuth.instance.currentUser?.email}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20),),
                  ),

                  ListTile(
                    onTap:()async{
                      modifypass("Password","${results[index]["Password"]}");

                    },
                    focusColor: Colors.green,
                    hoverColor: Colors.green,
                    title: Text("Password",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing: Text("${results[index]["Password"]}",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20)),
                  ),
                  ListTile(
                    onTap: ()async{
                      modifynum("Number","${results[index]["Number"]}");
                    },
                    focusColor: Colors.green,
                    hoverColor: Colors.green,
                    title: Text("Phone Number",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing: Text(results[index]["Number"],style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20),),
                  ),
                  ListTile(
                    onTap: ()async{
                      modifyloc("Location","${results[index]["Location"]}");
                    },
                    focusColor: Colors.green,
                    hoverColor: Colors.green,
                    title: Text("Location",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing: Text(results[index]["Location"],style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.red),),
                  ),
                  ListTile(
                    onTap: (){
                      changepro();
                    },
                    focusColor: Colors.green,
                    hoverColor: Colors.green,
                    title: Text("Picture",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing:
                        CircleAvatar(
                          backgroundColor: Colors.white,
                          radius: 25,
                          backgroundImage: NetworkImage(
                            "${FirebaseAuth.instance.currentUser?.photoURL}"
                          ),
                          )

                  ),
                ],
              );

            }
        ),
      )
    );
  }



}