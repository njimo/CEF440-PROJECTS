
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';

final FirebaseAuth _auth = FirebaseAuth.instance;

//register with email & password & save username instantly
Future registerWithEmailAndPassword(String name, String password, String email) async {
  try {
    UserCredential result = await _auth.createUserWithEmailAndPassword(email: email, password: password);
    User ?user = result.user;
    await user?.updateDisplayName(name);
    await user?.reload();
    User? latestUser = FirebaseAuth.instance.currentUser;
    print('${latestUser?.displayName}');


  } catch(e) {
   print("${e.toString()}");
  }


}

