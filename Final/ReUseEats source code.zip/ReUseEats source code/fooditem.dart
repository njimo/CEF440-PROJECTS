import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:getwidget/components/avatar/gf_avatar.dart';
import 'package:getwidget/components/list_tile/gf_list_tile.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:outline_search_bar/outline_search_bar.dart';
import 'package:quickalert/quickalert.dart';

class fooditem extends StatefulWidget {
  const fooditem({Key? key}) : super(key: key);
  @override
  _fooditem createState() => _fooditem();

}
class _fooditem extends State<fooditem>{

  @override
  void initState() {
    getClient();
    cont_search.addListener(search);
    super.initState();
  }

  search(){
    print(cont_search.text);
    searchresults();
  }

  searchresults(){
    var showresults=[];
    if(cont_search.text != ""){
      for (var Client in _results){
        var name = Client['name'].toString().toLowerCase();
        var price = Client['price'].toString().toLowerCase();
        var Expdate= Client['Expdate'].toString().toLowerCase();
        var Cat = Client['Category'].toString().toLowerCase();
        if(name.contains(cont_search.text.toLowerCase()) || price.contains(cont_search.text.toLowerCase())
            || Expdate.contains(cont_search.text.toLowerCase()) || Cat.contains(cont_search.text.toLowerCase()))
        {
          showresults.add(Client);
        }
      }

    }else{
      showresults = List.from(_results);
    }
    setState(() {
      _searchresults = showresults;
    });
  }

  List _results= [];
  List _searchresults= [];
  final cont_search = TextEditingController();


  getClient()async{
    var data = await FirebaseFirestore.instance.collection("Food_Post").where("Username",
        isEqualTo: FirebaseAuth.instance.currentUser?.displayName.toString()).get();
    setState(() {
      _results = data.docs;
    });
    searchresults();
  }
  @override
  void dispose() {
    cont_search.removeListener(search);
    cont_search.dispose();
    super.dispose();
  }
  @override
  void didChangeDependencies() {
    getClient();
    super.didChangeDependencies();
  }


  @override
  Widget build(BuildContext context) {
    var collection = FirebaseFirestore.instance.collection("fd").get();
    return Scaffold(
      resizeToAvoidBottomInset: false,
backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          "My Food Items", style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(
          color: Colors.green,
        ),
        shadowColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          SizedBox(height: 15),
          Container(
            height: 40,
            margin: EdgeInsets.only(left: 10),
            alignment: Alignment.topLeft,
            padding: EdgeInsets.only(right: 16),
            child: OutlineSearchBar(
              textEditingController: cont_search,

              searchButtonIconColor: Colors.green,
              textInputAction: TextInputAction.search,
              backgroundColor: Colors.lightBlue.shade50,
              borderRadius: BorderRadius.all(Radius.circular(15)),
              searchButtonPosition: SearchButtonPosition.leading,
              enableSuggestions: true,
              clearButtonIconColor: Colors.green,
              elevation: 2,
              hintText: "Search....",
              hintStyle: GoogleFonts.akayaKanadaka(fontSize: 18),
              textStyle: GoogleFonts.akayaKanadaka(fontSize: 15),
            ),
          ),
          const SizedBox(height: 20),
          Container(
            height: MediaQuery.of(context).size.height -225,
            child: RefreshIndicator(
              onRefresh: (){
                return getClient();
              },
              child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _searchresults.length,
                  itemBuilder: (BuildContext context,int index){

                    return GFListTile(
                      focusColor: Colors.green,
                      color: Colors.white,
                      hoverColor: Colors.green,
                      onTap: (){
                        Navigator.push(context,MaterialPageRoute(builder: (context) => modpub(index: index,fid: _searchresults[index]['id'],list: _searchresults,)));
                      },
                      onLongPress: ()async{
                        return showDialog(context: context, builder: (context){
                          return AlertDialog(
                            content: Text("Delete This Item ?",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                            actions: [
                              MaterialButton(
                                color: Colors.green,
                                  onPressed: (){
                                    var mp = FirebaseFirestore.instance.collection("Food_Post");
                                    mp.doc(_searchresults[index]["id"]).delete();
                                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(duration:Duration(seconds: 1),content: Text("Deleted",style: GoogleFonts.akayaKanadaka(color: Colors.green),)));
                                    Navigator.pop(context);
                                  },
                              child: Text("Update",style: GoogleFonts.akayaKanadaka(fontSize: 15),),
                              )
                            ],
                          );
                        });
                      },
                      title:
                      Text(_searchresults[index]['name'],style: GoogleFonts.akayaKanadaka(fontSize: 20,)),

                      description: Row(
                        children: [
                          Icon(
                            Icons.fastfood_rounded,size: 12,color: Colors.green,
                          ),
                          Text(_searchresults[index]['Category'],style: GoogleFonts.akayaKanadaka(fontSize: 12,fontStyle: FontStyle.italic)),
                        ],
                      ),
                      avatar: GFAvatar(backgroundImage: NetworkImage(_searchresults[index]['Imageurl']),radius: 35,),
                      subTitle: Text(_searchresults[index]['price'],style: GoogleFonts.akayaKanadaka(fontSize: 15,wordSpacing: 14,fontWeight: FontWeight.bold,color: Colors.green)),
                      enabled: true,
                      icon: Text(_searchresults[index]['Expdate'],style: GoogleFonts.akayaKanadaka(color: Colors.red,fontWeight: FontWeight.bold),),

                    );


                  }),
            ),

          ),

        ],
      ),
    );
  }
  }

  class modpub extends StatefulWidget{
    const modpub( {Key? key, required this.index,required this.fid,required this.list}) : super(key: key);
    final int index;
    final String fid;
    final List list;
    @override

    _modpub createState() => _modpub();

  }


class _modpub extends State<modpub>{
  PlatformFile? pickedfile;
  String food = "";
  final TextEditingController cont_update = TextEditingController();
  final TextEditingController cont_date = TextEditingController();
  Future<QuerySnapshot<Map<String,dynamic>>> map = FirebaseFirestore.instance.collection("Food_Post").where("Username",
  isEqualTo: FirebaseAuth.instance.currentUser?.displayName.toString()).get();
  String imgurl = "";



  Future<void> modify(String value) async {
    return showDialog(context: context,
        builder: (context){
return AlertDialog(
  icon: Icon(Icons.update,color: Colors.green,size: 40,),
  title: Text("Update $value",style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold),),
  content: TextFormField(
    controller: cont_update,
    decoration: InputDecoration(
      hintText: "${_results[widget.index][value]}",
      hintStyle: GoogleFonts.akayaKanadaka()
    ),
  ),
  actions: [
    MaterialButton(
      color: Colors.green,
        onPressed:()async{
       var mod= FirebaseFirestore.instance.collection("Food_Post").doc(widget.fid);
       if (value == 'price'){
       mod.update({
         value:cont_update.text+"FCFA",
       }).onError((error, stackTrace) => print(error));}
       else{
         mod.update({
           value:cont_update.text,
         }).onError((error, stackTrace) => print(error));
       }
       ScaffoldMessenger.of(context).showSnackBar(SnackBar(duration:Duration(seconds: 1),content: Text("Updated",style: GoogleFonts.akayaKanadaka(color: Colors.green),)));
       Navigator.pop(context);
       cont_update.clear();
       getClient();
        },
      child: Text(
        "Update",style: GoogleFonts.akayaKanadaka(fontSize: 20),
      ),
    )
  ],
);
        }
    );

  }
  Future<void> modifycat()async{
    return showDialog(context: context,
        builder: (context){
      return AlertDialog(
        contentPadding: EdgeInsets.only(right: 10),
        icon: Icon(Icons.update,color: Colors.green,size: 40,),
        title: Text("Update Category",style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold),),
        content: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState){
            return Row(
                children: [
                  Radio(
                      activeColor: Colors.green,
                      value: "Raw",
                      groupValue: food,
                      onChanged: (value){
                        setState(() {
                          food = value as String;
                        });
                      }),
                  Text("Raw",style: GoogleFonts.akayaKanadaka(),),
                  SizedBox(width: 5,),
                  Radio(
                      activeColor: Colors.green,
                      value: "Cooked",
                      groupValue: food,
                      onChanged: (value){
                        setState(() {
                          food = value as String;
                        });

                      }),
                  Text("Cooked",style: GoogleFonts.akayaKanadaka(),),
                  SizedBox(width: 10,),
                  Radio(
                      activeColor: Colors.green,
                      value: "Fruits&Vegetables",
                      groupValue: food,
                      onChanged: (value){
                        setState(() {
                          food = value as String;
                        });

                      }),
                  Text("F&V",style: GoogleFonts.akayaKanadaka(),)

                ]
            );
          },
        ),
        actions: [
          MaterialButton(
            color: Colors.green,
            onPressed:(){
              var mod= FirebaseFirestore.instance.collection("Food_Post").doc(widget.fid);
              mod.update({
                "Category":food,
              }).onError((error, stackTrace) => print(error));
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(duration:Duration(seconds: 1),content: Text("Updated",style: GoogleFonts.akayaKanadaka(color: Colors.green),)));
Navigator.pop(context);
getClient();
            },
            child: Text(
              "Update",style: GoogleFonts.akayaKanadaka(fontSize: 20),
            ),
          )

        ],

      );
        });
  }
  Future<void> modifydate()async{
    return showDialog(context: context,
        builder: (context){
          return AlertDialog(
            icon: Icon(Icons.update,color: Colors.green,size: 40,),
            title: Text("Update Expiring date",style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold),),
            content: TextFormField(
              readOnly: true,
              onTap:  () async {
                DateTime? pickdate = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(), // can't choose a date before today
                    firstDate: DateTime(DateTime.now().year),
                    lastDate: DateTime(2500)
                );
                if (pickdate != null){
                  String formatdate = DateFormat('yyyy-MM-dd').format(pickdate);
                  setState(() {
                    cont_date.text = formatdate;
                  });
                }
              },
              controller: cont_date,
              decoration: InputDecoration(
                  hintText: "${_results[widget.index]["Expdate"]}",
                  hintStyle: GoogleFonts.akayaKanadaka()
              ),
            ),
            actions: [
              MaterialButton(
                color: Colors.green,
                onPressed:(){
                  var mod= FirebaseFirestore.instance.collection("Food_Post").doc(widget.fid);
                  mod.update({
                    "Expdate":cont_date.text,
                  }).onError((error, stackTrace) => print(error));
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(duration:Duration(seconds: 1),content: Text("Updated",style: GoogleFonts.akayaKanadaka(color: Colors.green),)));
                Navigator.pop(context);
                getClient();
                  },
                child: Text(
                  "Update",style: GoogleFonts.akayaKanadaka(fontSize: 20),
                ),
              )
            ],
          );
        }
    );

  }
  Future<void> modifypic()async{
    return showDialog(context: context,
        builder: (context){
          return AlertDialog(
            icon: Icon(Icons.update,color: Colors.green,size: 40,),
            title: Text("Update Picture",style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold),),
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return Container(
                child: Column(
                children: [
                if (pickedfile!=null)
                Container(
                height: 200,
                child: Image.file(
                File(pickedfile!.path!),
                fit: BoxFit.cover,
                frameBuilder: (BuildContext context, Widget child, int? frame, bool? wasSynchronouslyLoaded) {
                return child;
                },
                ),
                ),
                SizedBox(height: 10,),
                ElevatedButton(onPressed: selectpic,
                child: Text(
                "Select Picture ",style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold),
                )),

                ],
                ),
                );
                }
            ),
            actions: [
              MaterialButton(
                color: Colors.green,
                onPressed:()async{
                  Reference rootref = FirebaseStorage.instance.ref();
                  Reference rootref1 = FirebaseStorage.instance.refFromURL(widget.list[widget.index]["Imageurl"]);
                  rootref1.delete();
                  Reference imgfol = rootref.child('Pictures');

                  Reference foodim = imgfol.child('${pickedfile!.path}');
                  await foodim.putFile(File(pickedfile!.path!));
                  imgurl = await foodim.getDownloadURL();

                  var mod= FirebaseFirestore.instance.collection("Food_Post").doc(widget.fid);
                  mod.update({
                    "Imageurl":imgurl
                  }).onError((error, stackTrace) => print(error));
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(duration:Duration(seconds: 1),content: Text("Updated",style: GoogleFonts.akayaKanadaka(color: Colors.green),)));
                  Navigator.pop(context);
                  getClient();

                },
                child: Text(
                  "Update",style: GoogleFonts.akayaKanadaka(fontSize: 20),
                ),
              )
            ],
          );
        }
    );

  }
  Future selectpic() async{
    final result = await FilePicker.platform.pickFiles();
    if (result ==null) return;
    setState(() {
      pickedfile = result.files.first;
    });
  }



  @override
  void initState() {
    getClient();
    super.initState();
  }

List _results = [];
  getClient()async{

    var data = await FirebaseFirestore.instance.collection("Food_Post").where("Username",
        isEqualTo: FirebaseAuth.instance.currentUser?.displayName.toString()).get();

    setState(() {
      _results.clear();
      _results = data.docs;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          "Update Food Item", style: GoogleFonts.akayaKanadaka(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.black),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(
          color: Colors.green,
        ),
        shadowColor: Colors.white,
        elevation: 0,
      ),
      body: RefreshIndicator(
        onRefresh: ()async{
          return getClient();
        },
        child: ListView.builder(
          itemCount: 1,
            itemBuilder: (context,index){
              return Column(
                children: [
                  SizedBox(height:20),
                  ListTile(
                    onTap:()async{
                      modify("name");
                    },
                    focusColor: Colors.green,
                    hoverColor: Colors.green,
                    title: Text("Food Name",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing: Text(_results[widget.index]["name"],style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20),),
                  ),
                  ListTile(
                    onTap:()async{
                      modify("price");
                    },
                    focusColor: Colors.green,

                    hoverColor: Colors.green,
                    title: Text("Price",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing: Text(_results[widget.index]["price"],style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20),),
                  ),

                  ListTile(
                    onTap:()async{
                      modify("quantity");
                    },
                    focusColor: Colors.green,
                    hoverColor: Colors.green,
                    title: Text("Quantity",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing: Text(_results[widget.index]["quantity"],style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20),),
                  ),
                  ListTile(
                    onTap: ()async{
                      modifycat();
                    },
                    focusColor: Colors.green,
                    hoverColor: Colors.green,
                    title: Text("Category",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing: Text(_results[widget.index]["Category"],style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20),),
                  ),
                  ListTile(
                    onTap: ()async{
                      modifydate();
                    },
                    focusColor: Colors.green,
                    hoverColor: Colors.green,
                    title: Text("Expiring Date",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing: Text(_results[widget.index]["Expdate"],style: GoogleFonts.akayaKanadaka(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.red),),
                  ),
                  ListTile(
                    onTap: (){
                      modifypic();
                    },
                    focusColor: Colors.green,
                    hoverColor: Colors.green,
                    title: Text("Picture",style: GoogleFonts.akayaKanadaka(fontSize: 20),),
                    trailing: CircleAvatar(
                      radius: 25,
                      backgroundImage: NetworkImage(
                        "${_results[widget.index]["Imageurl"]}"
                      ),
                    ),
                  ),
                ],
              );
            }
        ),
      ),


    );

  }
  }



