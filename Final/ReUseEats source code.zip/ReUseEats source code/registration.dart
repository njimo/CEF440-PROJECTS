import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:progress_dialog_null_safe/progress_dialog_null_safe.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';
import 'package:untitled1/Interfaces/Homepage.dart';
import 'package:untitled1/Loginstyle/style.dart';
import 'package:untitled1/Interfaces/header_file.dart';

import 'Homescreen.dart';
import 'hh.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(MaterialApp(
    theme:ThemeData(
      primarySwatch: Colors.green
    ),
    debugShowCheckedModeBanner: false,
    home: Registration()
  ));
}

class Registration extends StatefulWidget{
  @override
  State<StatefulWidget> createState(){
    return _RegistrationState();
  }
}

class _RegistrationState extends State<StatefulWidget> {
  final _formkey = GlobalKey<FormState>();

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool checkedValue= false;
  CollectionReference _reference = FirebaseFirestore.instance.collection("Users");
  bool checkboxValue= false;
  final cont_uname=TextEditingController();
  final cont_pass=TextEditingController();
  final cont_email=TextEditingController();
  final cont_num=TextEditingController();
  final cont_loc=TextEditingController();
  bool toogle=true;

  @override
  Widget build(BuildContext context){
    final ProgressDialog pr = ProgressDialog(context,type: ProgressDialogType.normal, isDismissible: true, showLogs: false);
    pr.style(
        message: "Registering....",
        messageTextStyle: GoogleFonts.akayaKanadaka(fontSize: 20),
        progressTextStyle: TextStyle(color: Colors.green),
        elevation: 0,
        borderRadius: 15,
        insetAnimCurve: Curves.bounceInOut
    );

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Container(
              height: 140,
              child: HeaderWidget(150, false, Icons.person_add_alt),
            ),
            Container(
              margin:EdgeInsets.fromLTRB(25, 50, 25, 20),
              padding: EdgeInsets.fromLTRB(10, 0, 15, 0),
              alignment: Alignment.center,
              child: Column(
                children: [
                  Form(
                    key: _formkey,
                    child: Column(
                      children: [
    GestureDetector(
    child: Stack(
    children: [
    Container(
    padding: EdgeInsets.all(10),
    decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(100),
    border: Border.all(
    width: 5, color: Colors.white),
    color: Colors.white,
    boxShadow: [
    BoxShadow(
    color: Colors.black12,
    blurRadius: 20,
    offset: const Offset(5, 5),
    ),
    ],
    ),
    child: Icon(
    Icons.person,
    color: Colors.grey.shade300,
    size: 80.0,
    ),
    ),
    Container(
    padding: EdgeInsets.fromLTRB(80, 80, 0, 0),
    child: Icon(
    Icons.add_circle,
    color: Colors.grey.shade700,
    size: 25.0,
    ),
    ),

                      ],
                    ),
                  ),
                        SizedBox(height: 30,),
                        Container(
                          child: TextFormField(
                            style: GoogleFonts.akayaKanadaka(),
                            controller: cont_uname,
                            decoration: loginstyle().logindecoration('UserName', 'Enter your Username',Icons.supervisor_account),
                              validator: (val) {
                                if(val!.isEmpty){
                                  return ("Enter your password ");
                                }
                              }
                          ),
                          decoration: loginstyle().inputBoxDecorationShaddow(),
                        ),
                        SizedBox(height: 30,),
                        Container(
                          child: TextFormField(
                            obscureText: toogle,
                              style: GoogleFonts.akayaKanadaka(),
                            controller: cont_pass,
                            decoration:
                              InputDecoration(
                                labelText: "Password ",
                                  hintText: "At least 6 characters",
                                  hintStyle: GoogleFonts.akayaKanadaka(),
                                  fillColor: Colors.white, filled: true,
                                  labelStyle: GoogleFonts.akayaKanadaka(
                                      fontWeight: FontWeight.bold, fontStyle: FontStyle.italic
                                  ),
                                  prefixIcon: Icon(
                                    Icons.fingerprint_rounded, color: Colors.green,
                                  ),
                                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey)),
                                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey.shade400)),
                                  errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
                                  focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
                                suffixIcon: InkWell(
                                  onTap: () {
                                    setState(() {
                                      toogle = !toogle;
                                    });
                                  },
                                  child: Icon(
                                    toogle ?Icons.visibility_off :Icons.visibility
                                  ),
                                )

                              ),
    validator: (val) {
    if(val!.isEmpty){
    return ("Enter your password ");
    }}
                          ),
                          decoration: loginstyle().inputBoxDecorationShaddow(),
                        ),
                        SizedBox(height: 20.0),
                        Container(
                          child: TextFormField(
                            style: GoogleFonts.akayaKanadaka(),
                            controller: cont_email,
                            decoration: loginstyle().logindecoration("E-mail address", "Enter your email", Icons.email),
                            keyboardType: TextInputType.emailAddress,
                            validator: (val) {
                              if(val!.isEmpty){
                                print("Enter your email address");
                              }
                              bool email  = RegExp(r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(val);
                              if(!email){
                                return "Please enter a valid email address";
                              }

                            },
                          ),
                          decoration: loginstyle().inputBoxDecorationShaddow(),
                        ),
                        SizedBox(height: 20.0),
                        Container(
                          child: TextFormField(
                            style: GoogleFonts.akayaKanadaka(),
                            controller: cont_num,
                            decoration: loginstyle().logindecoration(
                                "Mobile Number",
                                "Enter your mobile number", Icons.phone),
                            keyboardType: TextInputType.phone,
                            validator: (val) {
                              if((val!.isEmpty) || !RegExp(r"^(\d+)*$").hasMatch(val)){
                                return "Enter a valid phone number";
                              }
                              return null;
                            },
                          ),
                          decoration: loginstyle().inputBoxDecorationShaddow(),
                        ),
                        SizedBox(height: 20.0),
                        Container(
                          child: TextFormField(
                            style: GoogleFonts.akayaKanadaka(),
                            controller: cont_loc,
                            decoration: loginstyle().logindecoration(
                                "Location",
                                "Give Your Location", Icons.location_city),
                            validator: (val) {
                              if(val!.isEmpty){
                                return ("Enter your location ");
                              }
                            },
                          ),
                          decoration: loginstyle().inputBoxDecorationShaddow(),
                        ),
SizedBox(height: 20,),
        FormField<bool>(
          builder: (state) {
            return Column(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Checkbox(
                        value: checkboxValue,
                        onChanged: (value) {
                          setState(() {
                            checkboxValue = value!;
                            state.didChange(value);
                          });
                        }),
                    Text("I accept all terms and conditions.", style: GoogleFonts.akayaKanadaka(
                        color: Colors.green,fontSize: 17,
                    fontWeight: FontWeight.bold)),
                  ],
                ),
                Container(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    state.errorText ?? '',
                    textAlign: TextAlign.left,
                    style: TextStyle(color: Theme.of(context).errorColor,fontSize: 12,),
                  ),
                )
              ],
            );
          },
          validator: (value) {
            if (!checkboxValue) {
              return 'You need to accept terms and conditions';
            } else {
              return null;
            }
          },

        ),
    SizedBox(height: 20.0),
    Container(
    decoration: loginstyle().boxDecoration(context),
    child: ElevatedButton(
      clipBehavior: Clip.hardEdge,
    style: loginstyle().buttonStyle(),
    onPressed: () async {
        if(_formkey.currentState!.validate()) {
          await pr.show();

            try {
              Map<String, String> toJson() =>
                  {
                    'Email': cont_email.text,
                    'Number': cont_num.text,
                    'Password': cont_pass.text,
                    'Username': cont_uname.text,
                    'Location': cont_loc.text,
                    'id': "",
                  };
              _reference.add(toJson()).onError((error, stackTrace) async {
                await pr.hide();
                QuickAlert.show(
                  context: context,
                  type: QuickAlertType.error,
                  title: 'Oops...',
                  text: '${error.toString()}',
                );
                throw 1;
              }).then((DocumentReference snapshot) {
                _reference.doc(snapshot.id).update({
                  'id': snapshot.id
                }).onError((error, stackTrace) async {
                  await pr.hide();
                  QuickAlert.show(
                    context: context,
                    type: QuickAlertType.error,
                    title: 'Oops...',
                    text: '${error.toString()}',
                  );
                  throw 1;
                });
              });
            } on Exception catch (e) {
              await pr.hide();
              QuickAlert.show(
                context: context,
                type: QuickAlertType.error,
                title: 'Oops...',
                text: '${e.toString()}',
              );
            }

          registerWithEmailAndPassword(
              cont_uname.text, cont_pass.text, cont_email.text).then((
              value) async {
            await pr.hide();
            Navigator.pop(context);
          }).onError((error, stackTrace) async {
            await pr.hide();
            QuickAlert.show(
              context: context,
              type: QuickAlertType.error,
              title: 'Oops...',
              text: '${error.toString()}',
            );
          });

        }

    },
    child: Padding(
    padding: const EdgeInsets.fromLTRB(40, 10, 40, 10),
    child: Text(
    "Register".toUpperCase(),
    style: GoogleFonts.akayaKanadaka(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    color: Colors.white,
    ),
    ),
    ),
    )
    )
                ],
              ),
            )
          ],
        ),
      )
      ]
        )
    )
    );
  }
  void goto(){
    Navigator.push(context, MaterialPageRoute(builder: (context) => Homepage()));

  }



}




  Future registerWithEmailAndPassword(String name, String password, String email) async {
    final FirebaseAuth _auth = FirebaseAuth.instance;

    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      User ?user = result.user;
      user?.updateDisplayName(name);
      user?.updatePhotoURL("https://cdn-icons-png.flaticon.com/512/21/21104.png");

      return user;
    } catch(e) {
      print(e.toString());
      return null;
    }
  }






