import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class loginstyle{
  InputDecoration logindecoration([String label="",String hint="",IconData? _icon,IconData? _icon1]){

    return InputDecoration(
      labelText: label,
      hintText: hint,
        hintStyle: GoogleFonts.akayaKanadaka(),
        labelStyle: GoogleFonts.akayaKanadaka( fontWeight: FontWeight.bold, fontStyle: FontStyle.italic),
        fillColor: Colors.white, filled: true,
        prefixIcon: Icon(
          _icon, color: Colors.green,
        ),

        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.grey.shade400)),
    errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0)),
        focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(100.0), borderSide: BorderSide(color: Colors.red, width: 2.0))
      );
  }



  ButtonStyle buttonStyle (){

    return ButtonStyle(
      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
        RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
      ),
          minimumSize: MaterialStateProperty.all(Size(50,50)),
      backgroundColor: MaterialStateProperty.all(Colors.transparent),
      shadowColor: MaterialStateProperty.all(Colors.transparent)
    );
  }

  BoxDecoration inputBoxDecorationShaddow() {
    return BoxDecoration(boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.1),
        blurRadius: 20,
        offset: const Offset(0, 5),
      )
    ]);
  }


  BoxDecoration boxDecoration(BuildContext context,[String color1="", String color2=""]){
    Color c1= Theme.of(context).primaryColor.withOpacity(0.4);
    Color c2= Theme.of(context).colorScheme.secondary.withOpacity(1);
    return BoxDecoration(
      boxShadow: [
        BoxShadow(color: Colors.black26,offset: Offset(0,4), blurRadius: 2.0)
      ],
     gradient: LinearGradient(
       begin: Alignment.topLeft,
       end: Alignment.bottomRight,
       stops: [0.0,1.0],
       colors: [
         c1,c2
       ]
     ),
        color: Colors.green.shade300,
      borderRadius:  BorderRadius.circular(30),
    );
  }



}